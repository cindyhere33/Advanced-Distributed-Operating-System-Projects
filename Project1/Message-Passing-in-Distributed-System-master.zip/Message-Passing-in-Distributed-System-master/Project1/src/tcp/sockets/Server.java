package tcp.sockets;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.net.ServerSocket;
import java.net.Socket;

import tcp.Main;
import tcp.Utils;
import tcp.models.Token;

public class Server extends Thread {

	ServerSocket ss;
	String hostName;
	Integer portNo;

	public Server(String hostName, Integer portNo) {
		this.hostName = hostName;
		this.portNo = portNo;
		try {
			ss = new ServerSocket(portNo);
			ss.setReuseAddress(true);
			Utils.log("Server started");
		} catch (IOException e) {
			e.printStackTrace();
			Utils.log("Error starting server " + Main.myNode.getId());
			try {
				ss.close();
			} catch (IOException e1) {
				e1.printStackTrace();
				Utils.log("Server socket closing exception");
			}
		}
	}

	@SuppressWarnings("deprecation")
	@Override
	public void destroy() {
		super.destroy();
		try {
			ss.close();
		} catch (IOException e) {
			Utils.log("Closed socket");
			e.printStackTrace();
		}
	}

	@Override
	public void run() {
		ObjectInputStream ois;
		try {
			while (true) {
				Socket sc = ss.accept();
				ois = new ObjectInputStream(sc.getInputStream());
				Token token = (Token) ois.readObject();
				// Utils.log("Received token of " +
				// token.getOriginNode().getId());
				handleToken(token);
				ois.close();
				sc.close();
			}
		} catch (IOException e) {
			e.printStackTrace();
			Utils.log("Server thread quit");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}

	private void handleToken(Token token) {
		if (token.isTerminationMessage()) {
			Utils.log("Termination message from " + token.getOriginNode().getId());
			discardToken(token);
		} else if (token.isPathComplete()) {
			Utils.log("Announcing termination to all nodes");
			Utils.log("Label value : " + Main.labelValue + "; Sum = " + token.getSum());
			announceTermination(token);
		} else {
			acknowledgeToken(token);
		}
	}

	private void acknowledgeToken(Token token) {
		if (token.getPath().get(token.getPath().size() - 1).getId().equalsIgnoreCase(Main.myNode.getId())) {
			token.setSum(token.getSum() + Main.labelValue);
			token.getPath().remove(token.getPath().size() - 1);
		} else {
			Utils.log(token.getOriginNode().getId() + "'s token received in error");
		}
		Client.sendToken(token);
	}

	private void announceTermination(Token token) {
		Main.isComplete = true;
		Utils.writeToFile_termination(token);
		token.setTermination(true);
		Client.broadcast(token, Main.nodeMap);
	}

	private void discardToken(Token token) {
		if (!token.getOriginNode().getHostName().equals(Main.myNode.getHostName())) {
			Main.isProcessTerminated.put(token.getOriginNode().getId(), true);
			Main.noOfTerminatedProcesses++;
			Utils.log("No Of Terminated Processes = " + Main.noOfTerminatedProcesses);
			if (Main.noOfTerminatedProcesses >= (Main.noNodes - 1) && Main.isComplete) {
				Utils.log("All processes terminated");
				Main.killServer();
				System.exit(0);
			}
		}
	}

}

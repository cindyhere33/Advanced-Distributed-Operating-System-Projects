package tcp.sockets;

import java.io.IOException;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.HashMap;

import tcp.Main;
import tcp.Utils;
import tcp.models.Node;
import tcp.models.Token;

public class Client {
	
	public static void sendToken(Token token) {
		Socket sc = null;
		Node nextNode = token.getPath().get(token.getPath().size() - 1);
		Utils.log("Passing " + token.getOriginNode().getId() + "\'s token to :  " + nextNode.getId());
		try {
			sc = new Socket(nextNode.getHostName(), nextNode.getPortNo());			
			sendToSocket(sc, token);
			sc.close();
		} catch (IOException e) {
			try {
				if(sc!=null && !sc.isClosed()) sc.close(); 
				e.printStackTrace();
			} catch (IOException e1) {
				Utils.log(" Socket could not be closed");
				e1.printStackTrace();
			}
			Utils.log("Error in TCPClient - " + Main.myNode.getId());
			e.printStackTrace();
		}
	}

	public static void sendToSocket(Socket socket, Token token) {
		ObjectOutputStream oos;
		try {
			oos = new ObjectOutputStream(socket.getOutputStream());
			oos.writeObject(token);
			oos.flush();
			oos.close();
			socket.close();
		} catch (IOException e) {
			Utils.log("Error in TCPClient - Socket exception");
			e.printStackTrace();
		}
	}

	public static void broadcast(Token token, HashMap<String, Node> neighbours) {
		for (String host : neighbours.keySet()) {
			if (neighbours.get(host).getHostName().equalsIgnoreCase(Main.myNode.getHostName()))
				continue;
			try {
				Socket socket = new Socket(neighbours.get(host).getHostName(), neighbours.get(host).getPortNo());
				sendToSocket(socket, token);
			} catch (IOException e) {
				e.printStackTrace();
				Utils.log("Cannot broadcast");
			}
		}
	}
}

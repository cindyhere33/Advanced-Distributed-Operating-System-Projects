#!/bin/bash
netid=sxk159231
PROJDIR=$HOME/CS6378/Project1
CONFIG=$PROJDIR/config.txt
BINDIR=$PROJDIR/bin
PROG=sctp/Main

noNodes=0
n=1
m=1

cat $CONFIG | sed -e "s/#.*//" | sed -e "/^\s*$/d" |
(
    read noNodes
    while read line || [[ -n "$line" ]]
    do
        if [ $n -lt 6 ]
        then
            host[$n]=$( echo $line | awk '{ print $2 }' )	
		    idd[$n]=$( echo $line | awk '{ print $1}' )
		    port[$n]=$( echo $line | awk '{ print $3 }')
		    #ssh -o "StrictHostKeyChecking no" $netid@$host "cd $BINDIR; java $PROG $idd $host $port " &		
            n=$(( n + 1 ))		
		elif [ $n -gt 5 ] 
		then
		    nodeNo=$(echo $line | awk '{ print $1 }')
		    noArgs=$(echo $line | gawk '{print NF}')
		    noNodesInPath[$nodeNo]=$((noArgs-1))
			
			for i in `seq 1 ${noNodesInPath[$nodeNo]}`
			do
				j=$((i+1))
				path[$i]=$(echo $line | awk '{ print $'$j' }' | sed 's/[^0-9]//g')
			done
			nodePath[nodeNo]=${path[@]}
			
        fi
    done  
    
    i=1
    noNodes=$( echo $noNodes | sed 's/\s//g')
    for i in `seq 1 $noNodes`
    do
        ssh -o "StrictHostKeyChecking no" $netid@${host[$i]} "cd $BINDIR; java $PROG $noNodes ${idd[$i]} ${host[$i]} ${port[$i]} ${idd[@]} ${host[@]} ${port[@]} ${noNodesInPath[${idd[$i]}]} ${nodePath[${idd[$i]}]}" &
    done
)


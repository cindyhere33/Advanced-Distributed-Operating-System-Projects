package tcp;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Random;

import tcp.models.Node;
import tcp.models.Token;

public class Utils {

	/*
	 * Data from config provided by launcher through command line arguments are
	 * all used to initialize node variables. Node's label value is assigned and
	 * token is generated.
	 */
	public static void initializeNode(String args[]) throws Exception {
		int i, noNodesInPath;
		List<Node> tokenPath = new ArrayList<>();
		Main.labelValue = new Random().nextInt(10) + 1;
		Main.noNodes = Integer.parseInt(args[0]);
		Main.myNode = new Node(args[1], args[2], args[3]);
		Main.nodeMap = new HashMap<>();
		for (i = 0; i < Main.noNodes; i++) {
			Node node = new Node(args[i + 4], args[(i + 4) + Main.noNodes], args[(i + 4 + 2 * Main.noNodes)]);
			Main.nodeMap.put(node.getId(), node);
		}
		noNodesInPath = Integer.parseInt(args[i + 4 + 2 * Main.noNodes]);
		int k = i + 5 + 2 * Main.noNodes;
		Node path[] = new Node[noNodesInPath + 1];
		path[0] = Main.myNode;
		for (int j = 0; j < noNodesInPath; j++) {
			path[noNodesInPath - j] = (Main.nodeMap.get(args[k + j]));
		}
		for (Node node : path) {
			tokenPath.add(node);
		}
		Main.noOfTerminatedProcesses = 0;
		Main.isComplete = false;
		Main.myToken = new Token(Main.myNode, false, tokenPath, Main.labelValue);
		for (String key : Main.nodeMap.keySet()) {
			Main.isProcessTerminated.put(key, false);
		}
	}

	/*
	 * Writes to file the label value of this node and the sum value computed by
	 * the token
	 */
	public static void writeToFile_termination(Token token) {
		File file = new File("Output" + Main.myNode.getId() + "_");
		String content = "My label value :  " + Main.labelValue + "\n" + token.getSum();
		try (FileOutputStream fop = new FileOutputStream(file)) {
			if (!file.exists()) {
				file.createNewFile();
			}
			byte[] contentInBytes = content.getBytes();
			fop.write(contentInBytes);
			fop.flush();
			fop.close();
			Utils.log("SUCCESS : Token written to file " + file.getAbsolutePath());
		} catch (IOException e) {
			e.printStackTrace();
			Utils.log("FAIL : Token write to file");
		}
	}

	/*
	 * Prints msg to console
	 */
	public static void log(String msg) {
		System.out.println(Main.myNode.getId() + " : " + msg);
	}

}

package tcp.models;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import tcp.Main;

public class Token implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 2L;
	// Store the path in reverse order. Start traversal from last node to first.
	// Keep stripping the last node as you traverse along the path
	List<Node> path = new ArrayList<>();
	Node originNode;
	Integer sum = 0;
	Boolean termination = false;

	public Token(Node node, Boolean isTerminator, List<Node> tokenPath, Integer sum) {
		this.originNode = node;
		this.termination = isTerminator;
		this.path = tokenPath;
		this.sum = sum;
	}

	public void addValue(Integer nodeLabel) {
		sum += nodeLabel;
	}

	public void stripLastNode() {
		path.remove(path.size() - 1);
	}

	public boolean isPathComplete() {
		return (path.size() == 1 && Main.myNode.getHostName().equals(path.get(0).getHostName()));
	}

	public List<Node> getPath() {
		return path;
	}

	public void setPath(List<Node> path) {
		this.path = path;
	}

	public Node getOriginNode() {
		return originNode;
	}

	public void setOriginNode(Node originNode) {
		this.originNode = originNode;
	}

	public Integer getSum() {
		return sum;
	}

	public void setSum(Integer sum) {
		this.sum = sum;
	}

	public Boolean isTerminationMessage() {
		return termination;
	}

	public void setTermination(Boolean termination) {
		this.termination = termination;
	}


}

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Parse {
	public static void main(String args[]) {
		String directory = "C:/Users/Sindhura/Documents/Subjects/Advanced Operating System/Projects/Project2_AOS/out.txt";
		FileReader fileReader;
		String line;
		Integer lineNo = 0;
		try {
			fileReader = new FileReader(directory);
			BufferedReader bufferedReader = new BufferedReader(fileReader);
			List<Node> nodes = new ArrayList<>();
			do {
				line = bufferedReader.readLine();
				lineNo++;
				if (line.split("\t").length < 1)
					continue;
				if (line.contains("Enter")) {
					String words[] = line.split("\t");
					SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss.SSS");
					Date date = sdf.parse(words[2]);
					Node node = new Node(words[0], date);
					nodes.add(node);
				} else if (line.contains("Exit")) {
					String words[] = line.split("\t");
					SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss.SSS");
					Date date = sdf.parse(words[2]);
					Integer index = -1;
					for (int i = 0; i < nodes.size(); i++) {
						Node node = nodes.get(i);
						if (node.enterTime.before(date)) {
							if (!node.nodeId.equals(words[0])) {
								System.out.println(" Critical sections overlap!!! at " + lineNo + "; " + node.nodeId
										+ ", " + words[0]);
								bufferedReader.close();
								return;
							}
						}
						for (Node n : nodes) {
							if (n.nodeId.equals(words[0])) {
								nodes.remove(n);
								break;
							}
						}
					}

				}
			} while (line != null);
			bufferedReader.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
}
